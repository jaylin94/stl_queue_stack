#ifndef STACK_HPP
#define STACK_HPP

void generatePalindrome(std::string userString, std::stack<char> &rStack);
void showStack(std::stack<char> &rStack);

#endif